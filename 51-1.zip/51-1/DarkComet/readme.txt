downloaded from the official website : darkcomet-rat.com
Project coded by DarkCoderSc.

Don't forget to visit my website : http://unremote.org/ and follow me on twitter (@DarkCoderSc) and Facebook!

Regards